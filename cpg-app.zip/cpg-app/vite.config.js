import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

function createOpenAIProxy(apiKey) {
  return async (req, res, next) => {
    if (req.method !== 'POST') {
      return next()
    }

    if (!apiKey) {
      res.statusCode = 500
      res.setHeader('Content-Type', 'application/json')
      res.end(JSON.stringify({
        error: 'Missing OPENAI_API_KEY. Add it in your shell or a .env file and restart Vite.'
      }))
      return
    }

    try {
      let body = ''
      for await (const chunk of req) body += chunk
      const payload = JSON.parse(body || '{}')

      const upstream = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          Authorization: `Bearer ${apiKey}`
        },
        body: JSON.stringify(payload)
      })

      const responseText = await upstream.text()
      res.statusCode = upstream.status
      res.setHeader('Content-Type', 'application/json')
      res.end(responseText)
    } catch (error) {
      res.statusCode = 500
      res.setHeader('Content-Type', 'application/json')
      res.end(JSON.stringify({
        error: `Proxy request failed: ${error?.message || 'Unknown error'}`
      }))
    }
  }
}

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const apiKey = env.OPENAI_API_KEY || process.env.OPENAI_API_KEY
  const proxyHandler = createOpenAIProxy(apiKey)

  return {
    plugins: [
      react(),
      {
        name: 'openai-dev-proxy',
        configureServer(server) {
          server.middlewares.use('/api/openai/chat/completions', proxyHandler)
        },
        configurePreviewServer(server) {
          server.middlewares.use('/api/openai/chat/completions', proxyHandler)
        }
      }
    ]
  }
})
