import { useState, useEffect, useCallback, useRef } from "react";

// ============================================================
// SYNTHETIC DATA: Products, Brands, Compliance Rules
// ============================================================

const PRODUCT_DATABASE = [
  {
    id: "p1",
    name: "PureGlow Vitamin C Serum",
    category: "Skincare",
    brand: "PureGlow Naturals",
    features: ["30% Vitamin C", "Hyaluronic Acid", "Ferulic Acid", "Vegan", "Cruelty-free"],
    benefits: ["Brightens skin tone", "Reduces dark spots", "Boosts collagen production", "Deep hydration"],
    usage: "Apply 3-4 drops to clean face morning and evening. Follow with moisturizer and SPF.",
    targetAudience: "Women 25-45, skincare enthusiasts, clean beauty advocates",
    pricePoint: "$34.99",
    usp: "Clinical-grade Vitamin C in a clean, sustainable formula"
  },
  {
    id: "p2",
    name: "FreshBite Protein Crunch Bars",
    category: "Food & Beverage",
    brand: "FreshBite Co.",
    features: ["20g protein", "Gluten-free", "No artificial sweeteners", "Non-GMO", "5g fiber"],
    benefits: ["Sustained energy", "Muscle recovery support", "Guilt-free snacking", "Keeps you full longer"],
    usage: "Enjoy as a post-workout snack or mid-day energy boost. Best served chilled.",
    targetAudience: "Fitness enthusiasts 18-40, health-conscious consumers, busy professionals",
    pricePoint: "$2.99/bar",
    usp: "Real food ingredients with macro-friendly nutrition"
  },
  {
    id: "p3",
    name: "EcoClean All-Purpose Spray",
    category: "Household",
    brand: "EcoClean Home",
    features: ["Plant-based formula", "Biodegradable", "No harsh chemicals", "Recyclable packaging", "EPA Safer Choice certified"],
    benefits: ["Cuts grease effectively", "Safe around kids and pets", "Fresh lavender scent", "Streak-free clean"],
    usage: "Spray directly on surfaces. Wipe with cloth. No rinsing needed.",
    targetAudience: "Eco-conscious families, parents with young children, sustainability advocates",
    pricePoint: "$6.49",
    usp: "Powerful cleaning without compromising your family's health or the planet"
  },
  {
    id: "p4",
    name: "ZenBrew Adaptogenic Coffee",
    category: "Food & Beverage",
    brand: "ZenBrew",
    features: ["Organic Arabica", "Lion's Mane mushroom", "Ashwagandha", "L-Theanine", "Medium roast"],
    benefits: ["Calm focus without jitters", "Enhanced cognitive function", "Stress reduction", "Smooth, rich flavor"],
    usage: "Brew 2 tbsp per 6oz water. French press or drip recommended. Enjoy hot or iced.",
    targetAudience: "Wellness-focused professionals 25-50, biohackers, mindful consumers",
    pricePoint: "$24.99/bag",
    usp: "Where ancient adaptogens meet artisan coffee"
  },
  {
    id: "p5",
    name: "LuxeLocks Keratin Repair Mask",
    category: "Haircare",
    brand: "LuxeLocks Paris",
    features: ["Keratin complex", "Argan oil", "Silk proteins", "Color-safe", "Sulfate-free"],
    benefits: ["Repairs damage in one use", "72-hour frizz control", "Salon-quality results at home", "Restores shine and elasticity"],
    usage: "Apply generously to damp hair. Leave for 5-10 minutes. Rinse thoroughly. Use weekly.",
    targetAudience: "Women 20-50 with color-treated or damaged hair, salon quality seekers",
    pricePoint: "$18.99",
    usp: "Parisian salon science in every jar"
  },
  {
    id: "p6",
    name: "TinyTots Organic Baby Wipes",
    category: "Baby Care",
    brand: "TinyTots",
    features: ["99% water", "Organic cotton", "Hypoallergenic", "Fragrance-free", "Compostable"],
    benefits: ["Gentle on sensitive skin", "No irritation or rashes", "Eco-friendly disposal", "Pediatrician recommended"],
    usage: "Gently wipe and dispose. Safe for face, hands, and diaper area.",
    targetAudience: "New parents, eco-conscious families, parents of babies with sensitive skin",
    pricePoint: "$8.99/80ct",
    usp: "Pure enough for the most precious skin on earth"
  }
];

const BRAND_STYLE_GUIDES = {
  "PureGlow Naturals": {
    tone: "Sophisticated, science-backed yet approachable, empowering",
    voiceTraits: ["Clean", "Confident", "Educational", "Aspirational"],
    doWords: ["radiance", "transform", "clinical-grade", "pure", "glow", "reveal"],
    dontWords: ["cheap", "miracle", "cure", "guaranteed results", "anti-aging"],
    colors: { primary: "#2D5016", accent: "#C9A96E" },
    tagline: "Science Meets Nature™"
  },
  "FreshBite Co.": {
    tone: "Energetic, fun, motivational, straightforward",
    voiceTraits: ["Bold", "Active", "Real", "Community-driven"],
    doWords: ["fuel", "crush it", "real food", "power", "clean", "strong"],
    dontWords: ["diet", "low-cal", "skinny", "cheat meal", "guilt"],
    colors: { primary: "#E85D26", accent: "#1B3A2D" },
    tagline: "Fuel Your Fire™"
  },
  "EcoClean Home": {
    tone: "Warm, trustworthy, eco-conscious, family-friendly",
    voiceTraits: ["Caring", "Transparent", "Sustainable", "Reliable"],
    doWords: ["protect", "pure", "planet-friendly", "safe", "naturally", "home"],
    dontWords: ["toxic", "chemical-free (misleading)", "100% safe", "kills all"],
    colors: { primary: "#2E7D32", accent: "#81C784" },
    tagline: "Clean Home, Clean Planet™"
  },
  "ZenBrew": {
    tone: "Mindful, premium, intellectual, calm confidence",
    voiceTraits: ["Wise", "Serene", "Elevated", "Intentional"],
    doWords: ["ritual", "clarity", "flow state", "craft", "mindful", "elevate"],
    dontWords: ["wired", "buzzed", "caffeine hit", "basic", "average"],
    colors: { primary: "#1A1A2E", accent: "#D4A574" },
    tagline: "Clarity in Every Cup™"
  },
  "LuxeLocks Paris": {
    tone: "Luxurious, French-inspired elegance, expert authority",
    voiceTraits: ["Glamorous", "Expert", "Indulgent", "Confident"],
    doWords: ["luxe", "transform", "salon-grade", "nourish", "silk", "radiant"],
    dontWords: ["cheap", "basic", "quick fix", "drugstore", "no-fuss"],
    colors: { primary: "#1C1C1C", accent: "#C9A96E" },
    tagline: "L'Art du Cheveu™"
  },
  "TinyTots": {
    tone: "Tender, reassuring, pure, parent-to-parent",
    voiceTraits: ["Gentle", "Trustworthy", "Pure", "Loving"],
    doWords: ["gentle", "pure", "precious", "nurture", "safe", "soft"],
    dontWords: ["tough", "strong", "powerful", "aggressive", "extreme"],
    colors: { primary: "#F5E6D3", accent: "#7FB5B5" },
    tagline: "Pure Love, Pure Care™"
  }
};

const COMPLIANCE_RULES = {
  Skincare: [
    { rule: "No disease treatment claims", severity: "critical", regex: /\b(cure|treat|heal|remedy)\b/gi },
    { rule: "No guaranteed results claims", severity: "critical", regex: /\b(guaranteed|100%|always works|permanent)\b/gi },
    { rule: "Must include 'results may vary' for efficacy claims", severity: "warning", regex: /\b(clinically proven|dermatologist tested)\b/gi },
    { rule: "No comparative superiority without evidence", severity: "warning", regex: /\b(best|#1|number one|superior to)\b/gi },
    { rule: "FDA disclaimer required for structure/function claims", severity: "info", regex: /\b(supports|promotes|helps maintain)\b/gi }
  ],
  "Food & Beverage": [
    { rule: "No disease prevention claims", severity: "critical", regex: /\b(prevents?|cures?|treats?|fights? disease)\b/gi },
    { rule: "No misleading health claims", severity: "critical", regex: /\b(superfood|miracle|magic)\b/gi },
    { rule: "Allergen info should be accessible", severity: "warning", regex: /\b(contains|may contain|allergen)\b/gi },
    { rule: "Nutritional claims must be substantiated", severity: "warning", regex: /\b(high protein|low sugar|zero calorie|no sugar)\b/gi },
    { rule: "Organic claims require certification", severity: "info", regex: /\b(organic|certified organic)\b/gi }
  ],
  Household: [
    { rule: "No absolute safety claims", severity: "critical", regex: /\b(100% safe|completely safe|totally harmless)\b/gi },
    { rule: "No 'chemical-free' claims (misleading)", severity: "warning", regex: /\b(chemical[ -]free|no chemicals)\b/gi },
    { rule: "EPA certification must be accurate", severity: "critical", regex: /\b(EPA certified|EPA approved)\b/gi },
    { rule: "Efficacy claims need qualification", severity: "warning", regex: /\b(kills 99|eliminates all|destroys)\b/gi }
  ],
  Haircare: [
    { rule: "No permanent change claims without evidence", severity: "critical", regex: /\b(permanent|forever|irreversible)\b/gi },
    { rule: "No medical claims", severity: "critical", regex: /\b(treats? hair loss|cures? dandruff|medical)\b/gi },
    { rule: "Time-based claims need substantiation", severity: "warning", regex: /\b(instant|immediate|overnight)\b/gi }
  ],
  "Baby Care": [
    { rule: "No absolute safety claims", severity: "critical", regex: /\b(100% safe|completely safe|zero risk)\b/gi },
    { rule: "Medical endorsement must be verified", severity: "critical", regex: /\b(doctor recommended|clinically proven|medically approved)\b/gi },
    { rule: "Age appropriateness must be specified", severity: "warning", regex: /\b(all ages|any age|newborn)\b/gi },
    { rule: "Ingredient transparency required", severity: "info", regex: /\b(natural|organic|pure)\b/gi }
  ]
};

const CHANNELS = [
  { id: "instagram", name: "Instagram Post", icon: "📸", maxLength: 2200, format: "Visual-first caption with hashtags" },
  { id: "facebook", name: "Facebook Ad", icon: "👥", maxLength: 1000, format: "Engaging ad copy with CTA" },
  { id: "email", name: "Email Campaign", icon: "📧", maxLength: 3000, format: "Subject line + body with sections" },
  { id: "twitter", name: "X/Twitter Post", icon: "🐦", maxLength: 280, format: "Concise, punchy with hashtags" },
  { id: "product_page", name: "Product Page", icon: "🛒", maxLength: 5000, format: "SEO-optimized product description" },
  { id: "print_ad", name: "Print Ad", icon: "📰", maxLength: 500, format: "Headline + body + tagline" },
  { id: "tvc_script", name: "TV/Video Script", icon: "🎬", maxLength: 3000, format: "30-second script with visuals" },
  { id: "sms", name: "SMS/WhatsApp", icon: "💬", maxLength: 160, format: "Short promotional message" }
];

const CAMPAIGN_TONES = ["Professional", "Playful", "Urgent", "Inspirational", "Educational", "Luxurious", "Eco-Conscious", "Bold & Edgy"];

// ============================================================
// COMPLIANCE CHECKER
// ============================================================

function checkCompliance(text, category) {
  const rules = COMPLIANCE_RULES[category] || [];
  const issues = [];
  rules.forEach(r => {
    const matches = text.match(r.regex);
    if (matches) {
      issues.push({ ...r, matches: [...new Set(matches)] });
    }
  });
  return issues;
}

function getComplianceScore(issues) {
  if (issues.some(i => i.severity === "critical")) return { score: "Needs Review", color: "#E53935", icon: "⚠️" };
  if (issues.some(i => i.severity === "warning")) return { score: "Caution", color: "#F9A825", icon: "⚡" };
  if (issues.length > 0) return { score: "Minor Notes", color: "#42A5F5", icon: "ℹ️" };
  return { score: "Compliant", color: "#43A047", icon: "✓" };
}

// ============================================================
// MAIN APP COMPONENT
// ============================================================

export default function CPGContentGenerator() {
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [selectedChannels, setSelectedChannels] = useState([]);
  const [campaignTone, setCampaignTone] = useState("Professional");
  const [customPrompt, setCustomPrompt] = useState("");
  const [targetSeason, setTargetSeason] = useState("General");
  const [numVariants, setNumVariants] = useState(2);
  const [generatedContent, setGeneratedContent] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState("generate");
  const [complianceResults, setComplianceResults] = useState([]);
  const [selectedVariant, setSelectedVariant] = useState(null);
  const [showProductDetail, setShowProductDetail] = useState(false);
  const [exportFormat, setExportFormat] = useState("txt");
  const [genProgress, setGenProgress] = useState(0);
  const [errorMsg, setErrorMsg] = useState("");
  const contentRef = useRef(null);

  const toggleChannel = (id) => {
    setSelectedChannels(prev =>
      prev.includes(id) ? prev.filter(c => c !== id) : [...prev, id]
    );
  };

  // AI Content Generation
  const generateContent = useCallback(async () => {
    if (!selectedProduct || selectedChannels.length === 0) return;
    setIsGenerating(true);
    setErrorMsg("");
    setGeneratedContent([]);
    setGenProgress(0);

    const product = PRODUCT_DATABASE.find(p => p.id === selectedProduct);
    const brand = BRAND_STYLE_GUIDES[product.brand];
    const channels = selectedChannels.map(id => CHANNELS.find(c => c.id === id));

    const totalCalls = channels.length;
    let completedCalls = 0;
    const allContent = [];

    for (const channel of channels) {
      try {
        const systemPrompt = `You are an expert CPG marketing copywriter. You produce high-converting, brand-compliant marketing content.

BRAND VOICE GUIDE for "${product.brand}":
- Tone: ${brand.tone}
- Voice Traits: ${brand.voiceTraits.join(", ")}
- Preferred Words: ${brand.doWords.join(", ")}
- Avoid These Words: ${brand.dontWords.join(", ")}
- Brand Tagline: ${brand.tagline}

COMPLIANCE RULES for ${product.category}:
${(COMPLIANCE_RULES[product.category] || []).map(r => `- ${r.severity.toUpperCase()}: ${r.rule}`).join("\n")}

You MUST respond ONLY with valid JSON. No markdown, no backticks, no explanation. The JSON format:
{
  "variants": [
    {
      "label": "Variant A label",
      "headline": "attention-grabbing headline",
      "body": "the main marketing copy",
      "cta": "call to action",
      "hashtags": ["tag1", "tag2"],
      "complianceNotes": "any compliance considerations"
    }
  ]
}`;

        const userPrompt = `Create ${numVariants} distinct marketing content variants for:

PRODUCT: ${product.name}
CATEGORY: ${product.category}
FEATURES: ${product.features.join(", ")}
BENEFITS: ${product.benefits.join(", ")}
USAGE: ${product.usage}
TARGET AUDIENCE: ${product.targetAudience}
PRICE: ${product.pricePoint}
USP: ${product.usp}

CHANNEL: ${channel.name}
FORMAT: ${channel.format}
MAX LENGTH: ${channel.maxLength} characters
CAMPAIGN TONE: ${campaignTone}
SEASON/OCCASION: ${targetSeason}
${customPrompt ? `ADDITIONAL DIRECTION: ${customPrompt}` : ""}

Each variant should take a DIFFERENT creative angle (e.g., benefit-led, story-driven, social-proof, urgency-based, educational). Make them genuinely distinct so they're useful for A/B testing.`;

        const response = await fetch("/api/openai/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model: "gpt-4o-mini",
            max_tokens: 1000,
            response_format: { type: "json_object" },
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: userPrompt }
            ]
          })
        });

        const data = await response.json();
        if (!response.ok) {
          throw new Error(data?.error || data?.message || `Request failed with status ${response.status}`);
        }
        const textContent = data?.choices?.[0]?.message?.content;
        const text = Array.isArray(textContent)
          ? textContent.map(i => i?.text || "").join("")
          : (textContent || "");
        const cleaned = text.replace(/```json|```/g, "").trim();
        const parsed = JSON.parse(cleaned);

        allContent.push({
          channel,
          variants: parsed.variants.map((v, i) => ({
            ...v,
            id: `${channel.id}-v${i}`,
            channel: channel.name,
            channelId: channel.id,
            channelIcon: channel.icon,
            compliance: checkCompliance(
              `${v.headline} ${v.body} ${v.cta}`,
              product.category
            )
          }))
        });
      } catch (err) {
        allContent.push({
          channel,
          variants: [{
            id: `${channel.id}-err`,
            label: "Generation Error",
            headline: "Content could not be generated",
            body: `Error: ${err.message}. Please try again.`,
            cta: "",
            hashtags: [],
            complianceNotes: "",
            channel: channel.name,
            channelId: channel.id,
            channelIcon: channel.icon,
            compliance: []
          }]
        });
      }
      completedCalls++;
      setGenProgress(Math.round((completedCalls / totalCalls) * 100));
    }

    setGeneratedContent(allContent);
    setIsGenerating(false);
    setActiveTab("results");
  }, [selectedProduct, selectedChannels, campaignTone, customPrompt, targetSeason, numVariants]);

  // Export content
  const exportContent = useCallback(() => {
    if (generatedContent.length === 0) return;
    const product = PRODUCT_DATABASE.find(p => p.id === selectedProduct);

    let output = "";
    if (exportFormat === "txt") {
      output += `═══════════════════════════════════════════\n`;
      output += `  CPG MARKETING CONTENT EXPORT\n`;
      output += `  Product: ${product.name}\n`;
      output += `  Brand: ${product.brand}\n`;
      output += `  Generated: ${new Date().toLocaleDateString()}\n`;
      output += `═══════════════════════════════════════════\n\n`;

      generatedContent.forEach(gc => {
        output += `━━━ ${gc.channel.icon} ${gc.channel.name} ━━━\n\n`;
        gc.variants.forEach((v, i) => {
          output += `--- Variant ${String.fromCharCode(65 + i)}: ${v.label} ---\n`;
          output += `Headline: ${v.headline}\n\n`;
          output += `${v.body}\n\n`;
          if (v.cta) output += `CTA: ${v.cta}\n`;
          if (v.hashtags?.length) output += `Hashtags: ${v.hashtags.map(h => `#${h}`).join(" ")}\n`;
          const cs = getComplianceScore(v.compliance);
          output += `\nCompliance: ${cs.icon} ${cs.score}\n`;
          if (v.compliance.length > 0) {
            v.compliance.forEach(c => {
              output += `  [${c.severity.toUpperCase()}] ${c.rule} (matched: ${c.matches.join(", ")})\n`;
            });
          }
          if (v.complianceNotes) output += `Notes: ${v.complianceNotes}\n`;
          output += `\n`;
        });
      });
    } else if (exportFormat === "json") {
      output = JSON.stringify({
        meta: {
          product: product.name,
          brand: product.brand,
          generatedAt: new Date().toISOString(),
          campaignTone,
          season: targetSeason
        },
        content: generatedContent.map(gc => ({
          channel: gc.channel.name,
          variants: gc.variants.map(v => ({
            label: v.label,
            headline: v.headline,
            body: v.body,
            cta: v.cta,
            hashtags: v.hashtags,
            complianceScore: getComplianceScore(v.compliance).score,
            complianceIssues: v.compliance.map(c => ({
              severity: c.severity,
              rule: c.rule,
              matches: c.matches
            })),
            complianceNotes: v.complianceNotes
          }))
        }))
      }, null, 2);
    } else if (exportFormat === "csv") {
      output = "Channel,Variant,Headline,Body,CTA,Hashtags,Compliance Score,Issues\n";
      generatedContent.forEach(gc => {
        gc.variants.forEach((v, i) => {
          const cs = getComplianceScore(v.compliance);
          const esc = (s) => `"${(s || "").replace(/"/g, '""')}"`;
          output += `${esc(gc.channel.name)},${esc(v.label)},${esc(v.headline)},${esc(v.body)},${esc(v.cta)},${esc((v.hashtags || []).join(" "))},${esc(cs.score)},${esc(v.compliance.map(c => c.rule).join("; "))}\n`;
        });
      });
    }

    const blob = new Blob([output], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `cpg-content-${product.name.replace(/\s+/g, "-").toLowerCase()}-${Date.now()}.${exportFormat === "json" ? "json" : exportFormat === "csv" ? "csv" : "txt"}`;
    a.click();
    URL.revokeObjectURL(url);
  }, [generatedContent, selectedProduct, exportFormat, campaignTone, targetSeason]);

  const product = selectedProduct ? PRODUCT_DATABASE.find(p => p.id === selectedProduct) : null;
  const brand = product ? BRAND_STYLE_GUIDES[product.brand] : null;

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0A0A0F",
      color: "#E8E6E1",
      fontFamily: "'DM Sans', 'Helvetica Neue', sans-serif",
      position: "relative",
      overflow: "hidden"
    }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />

      {/* Ambient background */}
      <div style={{
        position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none",
        background: "radial-gradient(ellipse at 20% 0%, rgba(99,102,241,0.08) 0%, transparent 60%), radial-gradient(ellipse at 80% 100%, rgba(236,72,153,0.06) 0%, transparent 60%)"
      }} />

      {/* Header */}
      <header style={{
        position: "sticky", top: 0, zIndex: 50,
        background: "rgba(10,10,15,0.85)", backdropFilter: "blur(20px)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        padding: "0 32px"
      }}>
        <div style={{
          maxWidth: 1400, margin: "0 auto",
          display: "flex", alignItems: "center", justifyContent: "space-between",
          height: 64
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: "linear-gradient(135deg, #6366F1, #EC4899)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 18, fontWeight: 700
            }}>C</div>
            <div>
              <div style={{ fontSize: 16, fontWeight: 600, letterSpacing: "-0.02em" }}>ContentForge</div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", letterSpacing: "0.1em", textTransform: "uppercase" }}>CPG Marketing AI</div>
            </div>
          </div>

          <nav style={{ display: "flex", gap: 4 }}>
            {[
              { id: "generate", label: "Generate", icon: "✦" },
              { id: "results", label: "Results", icon: "◈", count: generatedContent.reduce((s, g) => s + g.variants.length, 0) },
              { id: "library", label: "Product Library", icon: "◇" }
            ].map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
                padding: "8px 16px", borderRadius: 8, border: "none", cursor: "pointer",
                fontSize: 13, fontWeight: 500, fontFamily: "inherit",
                display: "flex", alignItems: "center", gap: 6,
                background: activeTab === tab.id ? "rgba(99,102,241,0.15)" : "transparent",
                color: activeTab === tab.id ? "#A5B4FC" : "rgba(255,255,255,0.5)",
                transition: "all 0.2s"
              }}>
                <span style={{ fontSize: 14 }}>{tab.icon}</span>
                {tab.label}
                {tab.count > 0 && (
                  <span style={{
                    background: "#6366F1", color: "#fff", fontSize: 10,
                    padding: "1px 6px", borderRadius: 10, fontWeight: 600
                  }}>{tab.count}</span>
                )}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main style={{ maxWidth: 1400, margin: "0 auto", padding: "32px 32px 80px", position: "relative", zIndex: 1 }}>

        {/* ============ GENERATE TAB ============ */}
        {activeTab === "generate" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: 32 }}>

            {/* Left: Configuration */}
            <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>

              {/* Step 1: Product Selection */}
              <section style={sectionStyle}>
                <div style={sectionHeaderStyle}>
                  <span style={stepBadgeStyle}>1</span>
                  <h2 style={sectionTitleStyle}>Select Product</h2>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12 }}>
                  {PRODUCT_DATABASE.map(p => {
                    const b = BRAND_STYLE_GUIDES[p.brand];
                    return (
                      <button key={p.id} onClick={() => { setSelectedProduct(p.id); setShowProductDetail(true); }}
                        style={{
                          padding: 16, borderRadius: 12, border: "1px solid",
                          borderColor: selectedProduct === p.id ? "#6366F1" : "rgba(255,255,255,0.08)",
                          background: selectedProduct === p.id ? "rgba(99,102,241,0.08)" : "rgba(255,255,255,0.02)",
                          cursor: "pointer", textAlign: "left", fontFamily: "inherit",
                          color: "#E8E6E1", transition: "all 0.2s",
                          position: "relative", overflow: "hidden"
                        }}>
                        <div style={{
                          position: "absolute", top: 0, right: 0, width: 60, height: 60,
                          background: `radial-gradient(circle at top right, ${b.colors.primary}33, transparent)`,
                        }} />
                        <div style={{ fontSize: 11, color: b.colors.accent, fontWeight: 600, letterSpacing: "0.05em", textTransform: "uppercase", marginBottom: 4 }}>{p.category}</div>
                        <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 2 }}>{p.name}</div>
                        <div style={{ fontSize: 12, color: "rgba(255,255,255,0.45)" }}>{p.brand} · {p.pricePoint}</div>
                      </button>
                    );
                  })}
                </div>
              </section>

              {/* Step 2: Channels */}
              <section style={sectionStyle}>
                <div style={sectionHeaderStyle}>
                  <span style={stepBadgeStyle}>2</span>
                  <h2 style={sectionTitleStyle}>Select Channels</h2>
                  <span style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", marginLeft: "auto" }}>{selectedChannels.length} selected</span>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
                  {CHANNELS.map(ch => (
                    <button key={ch.id} onClick={() => toggleChannel(ch.id)}
                      style={{
                        padding: "12px 8px", borderRadius: 10, border: "1px solid",
                        borderColor: selectedChannels.includes(ch.id) ? "#6366F1" : "rgba(255,255,255,0.08)",
                        background: selectedChannels.includes(ch.id) ? "rgba(99,102,241,0.1)" : "rgba(255,255,255,0.02)",
                        cursor: "pointer", fontFamily: "inherit", color: "#E8E6E1",
                        textAlign: "center", transition: "all 0.2s", fontSize: 12
                      }}>
                      <div style={{ fontSize: 20, marginBottom: 4 }}>{ch.icon}</div>
                      <div style={{ fontWeight: 500, fontSize: 11 }}>{ch.name}</div>
                    </button>
                  ))}
                </div>
              </section>

              {/* Step 3: Campaign Config */}
              <section style={sectionStyle}>
                <div style={sectionHeaderStyle}>
                  <span style={stepBadgeStyle}>3</span>
                  <h2 style={sectionTitleStyle}>Campaign Settings</h2>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                  <div>
                    <label style={labelStyle}>Tone</label>
                    <select value={campaignTone} onChange={e => setCampaignTone(e.target.value)} style={selectStyle}>
                      {CAMPAIGN_TONES.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={labelStyle}>Season / Occasion</label>
                    <select value={targetSeason} onChange={e => setTargetSeason(e.target.value)} style={selectStyle}>
                      {["General", "Spring/Summer", "Fall/Winter", "Holiday Season", "New Year", "Valentine's Day", "Mother's Day", "Back to School", "Black Friday", "Earth Day"].map(s => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label style={labelStyle}>A/B Variants per Channel</label>
                    <div style={{ display: "flex", gap: 8 }}>
                      {[1, 2, 3].map(n => (
                        <button key={n} onClick={() => setNumVariants(n)} style={{
                          flex: 1, padding: "10px", borderRadius: 8, border: "1px solid",
                          borderColor: numVariants === n ? "#6366F1" : "rgba(255,255,255,0.08)",
                          background: numVariants === n ? "rgba(99,102,241,0.15)" : "rgba(255,255,255,0.02)",
                          color: "#E8E6E1", cursor: "pointer", fontFamily: "inherit",
                          fontSize: 14, fontWeight: 600
                        }}>{n}</button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label style={labelStyle}>Export Format</label>
                    <select value={exportFormat} onChange={e => setExportFormat(e.target.value)} style={selectStyle}>
                      <option value="txt">Plain Text (.txt)</option>
                      <option value="json">JSON (.json)</option>
                      <option value="csv">CSV (.csv)</option>
                    </select>
                  </div>
                </div>
                <div style={{ marginTop: 16 }}>
                  <label style={labelStyle}>Additional Creative Direction (Optional)</label>
                  <textarea value={customPrompt} onChange={e => setCustomPrompt(e.target.value)}
                    placeholder="E.g., 'Focus on sustainability angle', 'Include a customer testimonial style', 'Target Gen Z language'..."
                    style={{
                      ...selectStyle, height: 80, resize: "vertical",
                      fontFamily: "inherit"
                    }} />
                </div>
              </section>

              {/* Generate Button */}
              <button onClick={generateContent}
                disabled={!selectedProduct || selectedChannels.length === 0 || isGenerating}
                style={{
                  padding: "18px 32px", borderRadius: 14, border: "none",
                  background: (!selectedProduct || selectedChannels.length === 0)
                    ? "rgba(255,255,255,0.05)"
                    : "linear-gradient(135deg, #6366F1, #8B5CF6, #EC4899)",
                  color: (!selectedProduct || selectedChannels.length === 0) ? "rgba(255,255,255,0.25)" : "#fff",
                  fontSize: 16, fontWeight: 600, fontFamily: "inherit",
                  cursor: (!selectedProduct || selectedChannels.length === 0) ? "not-allowed" : "pointer",
                  transition: "all 0.3s", letterSpacing: "-0.01em",
                  position: "relative", overflow: "hidden"
                }}>
                {isGenerating ? (
                  <span style={{ display: "flex", alignItems: "center", gap: 10, justifyContent: "center" }}>
                    <span style={{ animation: "spin 1s linear infinite", display: "inline-block" }}>◌</span>
                    Generating {genProgress}%
                  </span>
                ) : (
                  `✦ Generate ${selectedChannels.length} Channel${selectedChannels.length !== 1 ? "s" : ""} × ${numVariants} Variant${numVariants !== 1 ? "s" : ""}`
                )}
              </button>
              {isGenerating && (
                <div style={{ height: 3, borderRadius: 2, background: "rgba(255,255,255,0.05)", overflow: "hidden" }}>
                  <div style={{
                    height: "100%", borderRadius: 2, transition: "width 0.5s ease",
                    background: "linear-gradient(90deg, #6366F1, #EC4899)",
                    width: `${genProgress}%`
                  }} />
                </div>
              )}
              {errorMsg && <div style={{ color: "#EF4444", fontSize: 13, padding: 12, background: "rgba(239,68,68,0.1)", borderRadius: 8 }}>{errorMsg}</div>}
            </div>

            {/* Right: Product Preview Panel */}
            <div style={{ position: "sticky", top: 96, alignSelf: "start" }}>
              {product ? (
                <div style={{
                  borderRadius: 16, border: "1px solid rgba(255,255,255,0.08)",
                  background: "rgba(255,255,255,0.02)", overflow: "hidden"
                }}>
                  {/* Brand color header */}
                  <div style={{
                    height: 80,
                    background: `linear-gradient(135deg, ${brand.colors.primary}, ${brand.colors.primary}88)`,
                    display: "flex", alignItems: "flex-end", padding: "0 20px 12px",
                  }}>
                    <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "rgba(255,255,255,0.7)" }}>
                      {brand.tagline}
                    </div>
                  </div>

                  <div style={{ padding: 20 }}>
                    <div style={{ fontSize: 11, color: brand.colors.accent, fontWeight: 600, letterSpacing: "0.05em", textTransform: "uppercase", marginBottom: 4 }}>{product.category}</div>
                    <h3 style={{ fontSize: 20, fontWeight: 700, marginBottom: 4, fontFamily: "'Playfair Display', serif" }}>{product.name}</h3>
                    <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", marginBottom: 16 }}>{product.brand} · {product.pricePoint}</div>

                    <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", lineHeight: 1.6, marginBottom: 16 }}>{product.usp}</div>

                    <div style={{ marginBottom: 16 }}>
                      <div style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.4)", marginBottom: 8, letterSpacing: "0.05em", textTransform: "uppercase" }}>Features</div>
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                        {product.features.map(f => (
                          <span key={f} style={{
                            padding: "4px 10px", borderRadius: 20, fontSize: 11,
                            background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.6)",
                            border: "1px solid rgba(255,255,255,0.08)"
                          }}>{f}</span>
                        ))}
                      </div>
                    </div>

                    <div style={{ marginBottom: 16 }}>
                      <div style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.4)", marginBottom: 8, letterSpacing: "0.05em", textTransform: "uppercase" }}>Benefits</div>
                      {product.benefits.map(b => (
                        <div key={b} style={{ fontSize: 12, color: "rgba(255,255,255,0.6)", padding: "3px 0", display: "flex", gap: 8, alignItems: "center" }}>
                          <span style={{ color: brand.colors.accent }}>→</span> {b}
                        </div>
                      ))}
                    </div>

                    <div style={{ marginBottom: 16 }}>
                      <div style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.4)", marginBottom: 8, letterSpacing: "0.05em", textTransform: "uppercase" }}>Brand Voice</div>
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                        {brand.voiceTraits.map(t => (
                          <span key={t} style={{
                            padding: "4px 10px", borderRadius: 20, fontSize: 11,
                            background: `${brand.colors.accent}15`, color: brand.colors.accent,
                            border: `1px solid ${brand.colors.accent}30`
                          }}>{t}</span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.4)", marginBottom: 8, letterSpacing: "0.05em", textTransform: "uppercase" }}>Target</div>
                      <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)" }}>{product.targetAudience}</div>
                    </div>
                  </div>
                </div>
              ) : (
                <div style={{
                  borderRadius: 16, border: "1px dashed rgba(255,255,255,0.1)",
                  padding: 40, textAlign: "center", color: "rgba(255,255,255,0.3)"
                }}>
                  <div style={{ fontSize: 40, marginBottom: 12 }}>◇</div>
                  <div style={{ fontSize: 14, fontWeight: 500 }}>Select a product to see details</div>
                  <div style={{ fontSize: 12, marginTop: 4 }}>Product attributes, brand voice, and compliance rules will appear here</div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ============ RESULTS TAB ============ */}
        {activeTab === "results" && (
          <div>
            {generatedContent.length === 0 ? (
              <div style={{
                textAlign: "center", padding: "80px 20px", color: "rgba(255,255,255,0.3)"
              }}>
                <div style={{ fontSize: 48, marginBottom: 16 }}>◈</div>
                <div style={{ fontSize: 18, fontWeight: 500, marginBottom: 8 }}>No content generated yet</div>
                <div style={{ fontSize: 14 }}>Go to the Generate tab to create marketing content</div>
              </div>
            ) : (
              <div>
                {/* Results header */}
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
                  <div>
                    <h2 style={{ fontSize: 22, fontWeight: 700, fontFamily: "'Playfair Display', serif", marginBottom: 4 }}>
                      Generated Content
                    </h2>
                    <div style={{ fontSize: 13, color: "rgba(255,255,255,0.45)" }}>
                      {product?.name} · {generatedContent.reduce((s, g) => s + g.variants.length, 0)} variants across {generatedContent.length} channels
                    </div>
                  </div>
                  <button onClick={exportContent} style={{
                    padding: "10px 20px", borderRadius: 10, border: "1px solid rgba(99,102,241,0.3)",
                    background: "rgba(99,102,241,0.1)", color: "#A5B4FC",
                    fontSize: 13, fontWeight: 500, cursor: "pointer", fontFamily: "inherit",
                    display: "flex", alignItems: "center", gap: 8
                  }}>
                    ↓ Export as {exportFormat.toUpperCase()}
                  </button>
                </div>

                {/* Content cards */}
                {generatedContent.map((gc, gi) => (
                  <div key={gi} style={{ marginBottom: 32 }}>
                    <div style={{
                      display: "flex", alignItems: "center", gap: 10, marginBottom: 16,
                      padding: "8px 0", borderBottom: "1px solid rgba(255,255,255,0.06)"
                    }}>
                      <span style={{ fontSize: 22 }}>{gc.channel.icon}</span>
                      <span style={{ fontSize: 16, fontWeight: 600 }}>{gc.channel.name}</span>
                      <span style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", marginLeft: 8 }}>
                        Max {gc.channel.maxLength} chars · {gc.channel.format}
                      </span>
                    </div>

                    <div style={{ display: "grid", gridTemplateColumns: gc.variants.length > 1 ? "repeat(auto-fit, minmax(400px, 1fr))" : "1fr", gap: 16 }}>
                      {gc.variants.map((v, vi) => {
                        const cs = getComplianceScore(v.compliance);
                        return (
                          <div key={v.id} style={{
                            borderRadius: 14, border: "1px solid rgba(255,255,255,0.08)",
                            background: "rgba(255,255,255,0.02)", overflow: "hidden",
                            transition: "all 0.2s"
                          }}>
                            {/* Variant header */}
                            <div style={{
                              padding: "12px 20px", display: "flex", alignItems: "center", justifyContent: "space-between",
                              borderBottom: "1px solid rgba(255,255,255,0.06)",
                              background: "rgba(255,255,255,0.02)"
                            }}>
                              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                <span style={{
                                  width: 24, height: 24, borderRadius: 6,
                                  background: "rgba(99,102,241,0.15)", color: "#A5B4FC",
                                  display: "flex", alignItems: "center", justifyContent: "center",
                                  fontSize: 12, fontWeight: 700
                                }}>{String.fromCharCode(65 + vi)}</span>
                                <span style={{ fontSize: 13, fontWeight: 600 }}>{v.label}</span>
                              </div>
                              <span style={{
                                padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 600,
                                background: `${cs.color}15`, color: cs.color,
                                border: `1px solid ${cs.color}30`
                              }}>
                                {cs.icon} {cs.score}
                              </span>
                            </div>

                            {/* Content */}
                            <div style={{ padding: 20 }}>
                              <div style={{
                                fontSize: 18, fontWeight: 700, marginBottom: 12,
                                fontFamily: "'Playfair Display', serif",
                                lineHeight: 1.3
                              }}>
                                {v.headline}
                              </div>

                              <div style={{
                                fontSize: 13, color: "rgba(255,255,255,0.7)",
                                lineHeight: 1.7, marginBottom: 16,
                                whiteSpace: "pre-wrap"
                              }}>
                                {v.body}
                              </div>

                              {v.cta && (
                                <div style={{
                                  padding: "10px 16px", borderRadius: 8,
                                  background: "rgba(99,102,241,0.08)",
                                  border: "1px solid rgba(99,102,241,0.15)",
                                  fontSize: 13, fontWeight: 600, color: "#A5B4FC",
                                  marginBottom: 12
                                }}>
                                  CTA: {v.cta}
                                </div>
                              )}

                              {v.hashtags?.length > 0 && (
                                <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 12 }}>
                                  {v.hashtags.map(h => (
                                    <span key={h} style={{
                                      padding: "3px 8px", borderRadius: 6, fontSize: 11,
                                      background: "rgba(236,72,153,0.1)", color: "#F472B6",
                                      border: "1px solid rgba(236,72,153,0.2)"
                                    }}>#{h}</span>
                                  ))}
                                </div>
                              )}

                              {/* Compliance details */}
                              {v.compliance.length > 0 && (
                                <div style={{
                                  padding: 12, borderRadius: 8, marginBottom: 8,
                                  background: "rgba(255,255,255,0.02)",
                                  border: "1px solid rgba(255,255,255,0.06)"
                                }}>
                                  <div style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.4)", marginBottom: 8, letterSpacing: "0.05em", textTransform: "uppercase" }}>
                                    Compliance Notes
                                  </div>
                                  {v.compliance.map((c, ci) => (
                                    <div key={ci} style={{
                                      fontSize: 12, padding: "4px 0",
                                      color: c.severity === "critical" ? "#EF4444" : c.severity === "warning" ? "#F59E0B" : "#60A5FA",
                                      display: "flex", gap: 6
                                    }}>
                                      <span>{c.severity === "critical" ? "●" : c.severity === "warning" ? "◐" : "○"}</span>
                                      <span>{c.rule} <span style={{ color: "rgba(255,255,255,0.3)" }}>({c.matches.join(", ")})</span></span>
                                    </div>
                                  ))}
                                </div>
                              )}

                              {v.complianceNotes && (
                                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", fontStyle: "italic" }}>
                                  📋 {v.complianceNotes}
                                </div>
                              )}

                              {/* Char count */}
                              <div style={{
                                marginTop: 12, display: "flex", justifyContent: "space-between",
                                fontSize: 11, color: "rgba(255,255,255,0.25)"
                              }}>
                                <span>{(v.headline + " " + v.body + " " + (v.cta || "")).length} chars</span>
                                <button onClick={() => {
                                  navigator.clipboard.writeText(`${v.headline}\n\n${v.body}${v.cta ? "\n\n" + v.cta : ""}${v.hashtags?.length ? "\n\n" + v.hashtags.map(h => "#" + h).join(" ") : ""}`);
                                }} style={{
                                  background: "none", border: "none", color: "rgba(255,255,255,0.4)",
                                  cursor: "pointer", fontSize: 11, fontFamily: "inherit",
                                  padding: "2px 8px", borderRadius: 4,
                                }}>
                                  📋 Copy
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ============ PRODUCT LIBRARY TAB ============ */}
        {activeTab === "library" && (
          <div>
            <h2 style={{ fontSize: 22, fontWeight: 700, fontFamily: "'Playfair Display', serif", marginBottom: 4 }}>Product Library</h2>
            <p style={{ fontSize: 13, color: "rgba(255,255,255,0.45)", marginBottom: 24 }}>
              Synthetic CPG product database with brand guidelines and regulatory compliance rules
            </p>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(420px, 1fr))", gap: 20 }}>
              {PRODUCT_DATABASE.map(p => {
                const b = BRAND_STYLE_GUIDES[p.brand];
                const rules = COMPLIANCE_RULES[p.category] || [];
                return (
                  <div key={p.id} style={{
                    borderRadius: 16, border: "1px solid rgba(255,255,255,0.08)",
                    background: "rgba(255,255,255,0.02)", overflow: "hidden"
                  }}>
                    <div style={{
                      height: 6,
                      background: `linear-gradient(90deg, ${b.colors.primary}, ${b.colors.accent})`
                    }} />
                    <div style={{ padding: 20 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", marginBottom: 12 }}>
                        <div>
                          <div style={{ fontSize: 11, color: b.colors.accent, fontWeight: 600, letterSpacing: "0.05em", textTransform: "uppercase" }}>{p.category}</div>
                          <div style={{ fontSize: 17, fontWeight: 700, fontFamily: "'Playfair Display', serif" }}>{p.name}</div>
                          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.45)" }}>{p.brand} · {p.pricePoint}</div>
                        </div>
                      </div>

                      <div style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", marginBottom: 12, lineHeight: 1.5 }}>{p.usp}</div>

                      <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginBottom: 12 }}>
                        {p.features.map(f => (
                          <span key={f} style={{ padding: "2px 8px", borderRadius: 4, fontSize: 10, background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.5)" }}>{f}</span>
                        ))}
                      </div>

                      <div style={{ marginBottom: 12 }}>
                        <div style={{ fontSize: 10, fontWeight: 600, color: "rgba(255,255,255,0.3)", marginBottom: 6, letterSpacing: "0.05em", textTransform: "uppercase" }}>Brand Voice</div>
                        <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)" }}>{b.tone}</div>
                        <div style={{ display: "flex", gap: 4, marginTop: 6 }}>
                          {b.voiceTraits.map(t => (
                            <span key={t} style={{
                              padding: "2px 8px", borderRadius: 10, fontSize: 10,
                              background: `${b.colors.accent}12`, color: b.colors.accent
                            }}>{t}</span>
                          ))}
                        </div>
                      </div>

                      <div>
                        <div style={{ fontSize: 10, fontWeight: 600, color: "rgba(255,255,255,0.3)", marginBottom: 6, letterSpacing: "0.05em", textTransform: "uppercase" }}>
                          Compliance Rules ({rules.length})
                        </div>
                        {rules.slice(0, 3).map((r, i) => (
                          <div key={i} style={{
                            fontSize: 11, padding: "2px 0",
                            color: r.severity === "critical" ? "#EF444488" : r.severity === "warning" ? "#F59E0B88" : "#60A5FA88"
                          }}>
                            {r.severity === "critical" ? "●" : "◐"} {r.rule}
                          </div>
                        ))}
                        {rules.length > 3 && (
                          <div style={{ fontSize: 11, color: "rgba(255,255,255,0.25)", marginTop: 2 }}>+{rules.length - 3} more rules</div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </main>

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::selection { background: rgba(99,102,241,0.3); }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 3px; }
        select option { background: #1a1a2e; color: #E8E6E1; }
      `}</style>
    </div>
  );
}

// ============================================================
// SHARED STYLES
// ============================================================

const sectionStyle = {
  borderRadius: 16,
  border: "1px solid rgba(255,255,255,0.08)",
  background: "rgba(255,255,255,0.02)",
  padding: 24,
};

const sectionHeaderStyle = {
  display: "flex",
  alignItems: "center",
  gap: 10,
  marginBottom: 16,
};

const stepBadgeStyle = {
  width: 24, height: 24, borderRadius: 8,
  background: "rgba(99,102,241,0.15)", color: "#A5B4FC",
  display: "inline-flex", alignItems: "center", justifyContent: "center",
  fontSize: 12, fontWeight: 700,
};

const sectionTitleStyle = {
  fontSize: 15, fontWeight: 600, letterSpacing: "-0.01em",
};

const labelStyle = {
  display: "block", fontSize: 12, fontWeight: 500,
  color: "rgba(255,255,255,0.5)", marginBottom: 6,
};

const selectStyle = {
  width: "100%", padding: "10px 12px", borderRadius: 8,
  border: "1px solid rgba(255,255,255,0.1)",
  background: "rgba(255,255,255,0.04)", color: "#E8E6E1",
  fontSize: 13, fontFamily: "'DM Sans', sans-serif",
  outline: "none",
};
